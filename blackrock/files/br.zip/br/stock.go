package br

import (
	"fmt"
	"io/ioutil"
	"time"
	"os"
	"bytes"
	"strconv"
	"encoding/csv"
	"encoding/gob"
)

type Stock struct {
	Ticker		string
	noTicker	bool
	Name		string
	Sector		string
	Location	string
	Exchange	string
	MarketCurrency	string	// Currency depending on the country and exchange it is listed on
	ForexRate	float64	// USD / MarketCurrency
	Price		float64	// [USD]
	MarketValue	float64 // [USD]
	Weight		float64 // [%]
	AmountOfShares	int
}

type Historical struct {
	Ticker		string
	Date		[]string
	Open		[]float64
	High		[]float64
	Low		[]float64
	Close		[]float64
	AdjClose	[]float64
	Volume		[]int
}

func (stock *Stock) String() {
	fmt.Println("Ticker: \t", stock.Ticker)
	fmt.Println("Name: \t\t", stock.Name)
	fmt.Println("Sector: \t", stock.Sector)
	fmt.Println("Location: \t", stock.Location)
	fmt.Println("Exchange: \t", stock.Exchange)
	fmt.Println("Market currency: ", stock.MarketCurrency)
	fmt.Println("Forex rate: \t", stock.ForexRate)
	fmt.Println("Price: \t\t", stock.Price)
	fmt.Println("Market value: \t", stock.MarketValue)
	fmt.Println("Weight: \t", stock.Weight)
	fmt.Println("# of shares: \t", stock.AmountOfShares)
}

func Download_historical() error {
	etfs, err := Load_etfs()
	if err != nil {
		panic(err)
	}

	for i := 0; i < len(etfs); i++ {
		body, err := Download("https://query1.finance.yahoo.com/v7/finance/download/" + etfs[i].Ticker + "?period1=1420070400&period2=1703980800&interval=1d&events=history&includeAdjustedClose=true")
		if err != nil {
			fmt.Println(etfs[i].Ticker)
			return err
		}

		err = ioutil.WriteFile("../csv_historicals/" + etfs[i].Ticker + ".csv", body, 0644)
		if err != nil {
			return err
		}

		time.Sleep(1)

		fmt.Println(fmt.Sprint(i + 1) + " / " + fmt.Sprint(len(etfs)))
	}

	return nil
}

func Init_historical() error {
	etfs, err := Load_etfs()
	if err != nil {
		panic(err)
	}

	var historicals []Historical
	for i := 0; i < len(etfs); i++ {
		body, err := ioutil.ReadFile("../csv_historicals/" + etfs[i].Ticker + ".csv")
		if err != nil {
			return err
		}

		reader := csv.NewReader(bytes.NewReader(body))

		records, err := reader.ReadAll()
		if err != nil {
			panic(err)
		}

		var historical Historical

		historical.Ticker = etfs[i].Ticker

		for j, record := range records {
			if j == 0 {
				continue
			}
			
			open, err := strconv.ParseFloat(record[1], 64)
			if err != nil {
				panic(err)
			}
			high, err := strconv.ParseFloat(record[2], 64)
			if err != nil {
				panic(err)
			}
			low, err := strconv.ParseFloat(record[3], 64)
			if err != nil {
				panic(err)
			}
			close, err := strconv.ParseFloat(record[4], 64)
			if err != nil {
				panic(err)
			}
			adjClose, err := strconv.ParseFloat(record[5], 64)
			if err != nil {
				panic(err)
			}
			volume, err := strconv.Atoi(record[6])
			if err != nil {
				panic(err)
			}

			historical.Date = append(historical.Date, record[0])
			historical.Open = append(historical.Open, open)
			historical.High = append(historical.High, high)
			historical.Low = append(historical.Low, low)
			historical.Close = append(historical.Close, close)
			historical.AdjClose = append(historical.AdjClose, adjClose)
			historical.Volume = append(historical.Volume, volume)
		}

		historicals = append(historicals, historical)

		fmt.Println(fmt.Sprint(i + 1) + " / " + fmt.Sprint(len(etfs)))
	}

	err = save_historicals(historicals)
	if err != nil {
		return err
	}

	return nil
}

func save_historicals(historicals []Historical) error {
	for i := 0; i < len(historicals); i++ {
		file, err := os.Create("../data_historicals/" + historicals[i].Ticker + ".bin")
		if err != nil {
			return err
		}

		encoder := gob.NewEncoder(file)

		err = encoder.Encode(historicals[i])
		if err != nil {
			return err
		}

		file.Close()
	}

	return nil
}

func Load_historicals() ([]Historical, error) {
	files, err := ioutil.ReadDir("../data_historicals")
	if err != nil {
		return nil, err
	}

	historicals := make([]Historical, len(files))
	for i, file := range files {
		file, err := os.Open("../data_historicals/" + file.Name())
		if err != nil {
			return nil, err
		}

		decoder := gob.NewDecoder(file)

		var historical Historical
		err = decoder.Decode(&historical)
		if err != nil {
			return nil, err
		}

		historicals[i] = historical

		file.Close()
	}

	return historicals, nil
}
