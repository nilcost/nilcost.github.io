package br

import (
	"io/ioutil"
	"net/http"
	"regexp"
	"strings"
	"os"
	"encoding/csv"
	"bytes"
	"strconv"
	"sync"
	"encoding/gob"
	"fmt"
)

type ETF struct {
	Ticker			string
	Name			string
	ProductID		string
	Link			string
	Equity			[]Stock
	EquityValue		float64
	NonEquity		int
	NonEquityValue		float64
	MarketCurrency		string	// [USD]
	TotalValue		float64	// [USD]
	SharesOutstanding	int
	MarketPrice		float64 // Closing price [USD]
	FairPrice		float64 // [USD]
	Premium			float64
	Date			string 	// ETF numbers valid as of Date
}

func (etf *ETF) String() {
	fmt.Println("Ticker: \t", etf.Ticker)
	fmt.Println("Name: \t\t", etf.Name)
	fmt.Println("ProductID: \t", etf.ProductID)
	fmt.Println("Link: \t", etf.Link)
	fmt.Println("Equity: \t", "See respective array etf.Equity")
	fmt.Println("Non equity: \t", etf.NonEquity)
	fmt.Println("Non equity value: \t", etf.NonEquityValue)
	fmt.Println("Mrkt currency: \t", etf.MarketCurrency)
	fmt.Println("Total value: \t", etf.TotalValue)
	fmt.Println("Shares out.: \t", etf.SharesOutstanding)
	fmt.Println("MarketPrice: \t", etf.MarketPrice)
	fmt.Println("Premium: \t", etf.Premium)
	fmt.Println("Date : \t\t", etf.Date)
}

func Download_etfs() error {
	etfs, err := downloadFundNames()
	if err != nil {
		return err
	}

	err = downloadFundDetails(etfs)
	if err != nil {
		return err
	}

	err = save_etfs(etfs)
	if err != nil {
		return err
	}

	return nil
}

func Init_etfs() error {
	etfs, err := Load_etfs()
	if err != nil {
		return err
	}

	for i := 0; i < len(etfs); i++ {
		etfs[i].Ticker = ""
		etfs[i].Equity = nil
		etfs[i].EquityValue = 0
		etfs[i].NonEquity = 0
		etfs[i].NonEquityValue = 0
		etfs[i].TotalValue = 0
		etfs[i].SharesOutstanding = 0
		etfs[i].MarketPrice = 0
		etfs[i].FairPrice = 0
		etfs[i].Premium = 0
		etfs[i].Date = ""
	}

	err = getFundDetails(etfs)
	if err != nil {
		return err
	}

	err = save_etfs(etfs)
	if err != nil {
		return err
	}

	return nil
}

func downloadFundNames() ([]ETF, error) {
	body, err := Download("https://www.ishares.com/us/products/etf-investments#/?productView=etf&fac=43535%7C43580%7C43581%7C43584%7C43585%7C43615&pageNumber=1&sortColumn=totalNetAssets&sortDirection=desc&dataView=keyFacts")
	if err != nil {
		return nil, err
	}

	links := getFundLinks(body)

	var etfs []ETF
	for i := 0; i < len(links); i++ {
		product := links[i][strings.Index(links[i], "products/") + len("products/"):]
		product = product[:strings.Index(product, "/")]
		etfs = append(etfs, ETF {
			Name: links[i][strings.LastIndex(links[i], "/") + 1:],
			ProductID: product,
			Link: links[i],
			MarketCurrency: "USD",
		})
	}

	return etfs, nil
}

func getFundLinks(body []byte) []string {
	pattern := `<a[^>]*href=["'](.*?)["']`
	re := regexp.MustCompile(pattern)

	matches := re.FindAllStringSubmatch(string(body), -1)
	
	var fundLinks []string

	for i, match := range matches {
		// Remove double links (Side effect from the parsed dynamic html page)
		if i % 2 == 0 {
			continue
		// Remove non etf links
		} else if !strings.Contains(match[1], "etf") {
			continue
		} else if (!strings.Contains(match[1], "/products/2") && !strings.Contains(match[1], "/products/3")) ||
		// Removes etfs where all holdings - the etfs product structure - are non equity (e.g. derivates like options, swaps or bonds and currencies only)
		strings.Contains(match[1], "cmbs") ||
		strings.Contains(match[1], "mbs") ||
		strings.Contains(match[1], "mortgage") ||
		strings.Contains(match[1], "clo") ||
		strings.Contains(match[1], "bond") ||
		strings.Contains(match[1], "income") ||
		strings.Contains(match[1], "target-date") ||
		strings.Contains(match[1], "yr") ||
		strings.Contains(match[1], "government") ||
		strings.Contains(match[1], "total-return-etf") ||
		strings.Contains(match[1], "gilts") ||
		strings.Contains(match[1], "loan") ||
		strings.Contains(match[1], "pfandbriefe") ||
		strings.Contains(match[1], "gold-trust-fund") || 
		strings.Contains(match[1], "ishares-gold-trust-micro") ||
		strings.Contains(match[1], "gold-usd-hedged") ||
		strings.Contains(match[1], "gold-chf-hedged") ||
		strings.Contains(match[1], "gold-ch-fund") ||
		strings.Contains(match[1], "gold-eur-hedged") ||
		strings.Contains(match[1], "silver-trust-fund") ||
		strings.Contains(match[1], "physical") ||
		strings.Contains(match[1], "transition-enabling-metals") ||
		strings.Contains(match[1], "strategy") ||
		strings.Contains(match[1], "lifepath-retirement-etf") ||
		strings.Contains(match[1], "allocation") ||
		strings.Contains(match[1], "index") ||
		strings.Contains(match[1], "blackrock-s-p-500") || // https://www.ishares.com/us/products/308765/ishares-s-p-500-index-fund#/
		strings.Contains(match[1], "blackrock-sp-500") ||
		strings.Contains(match[1], "tips") ||
		strings.Contains(match[1], "option") ||
		strings.Contains(match[1], "future") ||
		strings.Contains(match[1], "swap") ||
		strings.Contains(match[1], "multi-asset") ||
		strings.Contains(match[1], "transition-enabling-metals") ||
		strings.Contains(match[1], "ucits") { // part of a feeder vehicle structure (especially for european)
			continue
		}

		fundLinks = append(fundLinks, match[1])
	}

	return fundLinks
}

func downloadFundDetails(etfs []ETF) error {
	var (
		counter int
		waitGroup *sync.WaitGroup = &sync.WaitGroup{}
	)

	for i := 0; i < len(etfs); i++ {
		if counter == 20 {
			waitGroup.Wait()
			fmt.Println(fmt.Sprint(i + 1) + " / " + fmt.Sprint(len(etfs)))
			counter = 0
		}

		waitGroup.Add(1)
		counter++
		go func(i int) {
			body, err := Download("https://ishares.com" + etfs[i].Link)
			if err != nil {
				panic(err)
			}

			err = ioutil.WriteFile("../html_etfs/" + etfs[i].ProductID + ".html", body, 0644)
			if err != nil {
				panic(err)
			}

			index := bytes.Index(body, []byte(`<a class="icon-xls-export" href="`))
			var holdingsLink string
			if index != - 1{
				for j := index + len(`<a class="icon-xls-export" href="`); j < len(body); j++ {
					if body[j] == '"' {
						break
					}
					holdingsLink += string(body[j])
				}
			} else {
				fmt.Println(etfs[i].Link)
				panic("No holdings download link")
			}

			body, err = Download("https://ishares.com" + holdingsLink)
			if err != nil {
				panic(err)
			}

			body = body[bytes.Index(body, []byte("Ticker")):]
			body = body[:bytes.Index(body, []byte{10, 194, 160})]

			err = ioutil.WriteFile("../csv_etfs/" + etfs[i].ProductID + ".csv", body, 0644)
			if err != nil {
				panic(err)
			}

			waitGroup.Done()
		}(i)
	}

	waitGroup.Wait()

	fmt.Println(fmt.Sprint(len(etfs)) + " / " + fmt.Sprint(len(etfs)))

	return nil
}

func getFundDetails(etfs []ETF) error {
	var (
		counter int
		waitGroup *sync.WaitGroup = &sync.WaitGroup{}
	)

	for i := 0; i < len(etfs); i++ {
		if counter == 20 {
			waitGroup.Wait()
			fmt.Println(fmt.Sprint(i + 1) + " / " + fmt.Sprint(len(etfs)))
			counter = 0
		}
		waitGroup.Add(1)
		counter++
		go func(i int) {
			body, err := ioutil.ReadFile("../html_etfs/" + etfs[i].ProductID + ".html")
			if err != nil {
				panic(err)
			}

			tickerPrefix := `tradeItTicker = "`
			ti := bytes.Index(body, []byte(tickerPrefix))
			if ti != - 1 {
				for j := ti + len(tickerPrefix); j < len(body); j++ {
					if body[j] == '"' {
						break
					}
					etfs[i].Ticker += string(body[j])
				}
			} else {
				fmt.Println(etfs[i].Link)
				panic("Missing ticker")
			}

			datePrefix := `<span class="header-nav-label navAmount">`
			dPi := bytes.Index(body, []byte(datePrefix))
			if dPi != - 1 {
				for j := dPi + len(datePrefix) + len("\nNAV as of "); j < len(body); j++ {
					if body[j] == '<' {
						break
					} else if body[j] == '\n' {
						continue
					}
					etfs[i].Date += string(body[j])
				}
			} else {
				fmt.Println(etfs[i].Link)
				panic("Missing date")
			}

			sharesOutstandingPrefix := `Shares Outstanding`
			sOi := bytes.Index(body, []byte(sharesOutstandingPrefix))
			if sOi != - 1 {
				var iStr string
				for j := sOi + len(sharesOutstandingPrefix) + bytes.Index(body[sOi + len(sharesOutstandingPrefix):], []byte(`<span class="data">`)) + len(`<span class="data">`); j < len(body); j++ {
					if body[j] == '<' {
						break
					} else if body[j] == '\n' {
						continue
					} 
					iStr += string(body[j])
				}
				etfs[i].SharesOutstanding, err = strconv.Atoi(strings.ReplaceAll(iStr, ",", ""))
				if err != nil {
					panic(err)
				}
			} else {
				fmt.Println(etfs[i].Link)
				panic("Missing shares outstanding")
			}

			closingPricePrefix := `<span class="header-nav-data">`
			cPi := bytes.Index(body, []byte(closingPricePrefix))
			if cPi != - 1 {
				var fStr string

				for j := cPi + len(closingPricePrefix) + 2; j < len(body); j++ {
					if body[j] == '<' {
						break
					} else if body[j] == '\n' {
						continue
					}
					fStr += string(body[j])
				}
				etfs[i].MarketPrice, err = strconv.ParseFloat(strings.ReplaceAll(fStr, ",", ""), 64)
				if err != nil {
					panic(err)
				}
			} else {
				fmt.Println(etfs[i].Link)
				panic("Missing closing price")
			}

			body, err = ioutil.ReadFile("../csv_etfs/" + etfs[i].ProductID + ".csv")
			if err != nil {
				panic(err)
			}

			var reshape bool
			if bytes.Contains(body, []byte("Type")) {
				reshape = true
			}

			reader := csv.NewReader(bytes.NewReader(body))

			records, err := reader.ReadAll()
			if err != nil {
				panic(err)
			}

			var stock Stock

			for j, record := range records {
				if j == 0 {
					continue
				}

				if reshape {
					record = append(record[:2], record[2+1:]...)
				}

				if record[3] != "Equity" {
					marketValue, err := strconv.ParseFloat(strings.ReplaceAll(record[4], ",", ""), 64)
					if err != nil {
						panic(err)
					}
					etfs[i].NonEquity++
					etfs[i].NonEquityValue += marketValue 
					goto skip_asset
				}

				stock = Stock{}

				if record[0] == "-" {
					stock.Ticker = record[1]
					stock.noTicker = true
				} else {
					stock.Ticker = record[0]
				}
				
				stock.Name = record[1]
				stock.Sector = record[2]
				stock.Location = record[9]
				stock.Exchange = record[10]
				stock.MarketCurrency = record[13]

				stock.ForexRate, err = strconv.ParseFloat(strings.ReplaceAll(record[12], ",", ""), 64)
				if err != nil {
					panic(err)
				}

				stock.MarketValue, err = strconv.ParseFloat(strings.ReplaceAll(record[4], ",", ""), 64)
				if err != nil {
					panic(err)
				}

				stock.Weight, err = strconv.ParseFloat(strings.ReplaceAll(record[5], ",", ""), 64)
				if err != nil {
					panic(err)
				}

				stock.AmountOfShares, err = strconv.Atoi(strings.ReplaceAll(record[7][:strings.LastIndex(record[7], ".")], ",", ""))
				if err != nil {
					panic(err)
				}

				stock.Price, err = strconv.ParseFloat(strings.ReplaceAll(record[8], ",", ""), 64)
				if err != nil {
					panic(err)
				}

				etfs[i].Equity = append(etfs[i].Equity, stock)
				skip_asset:
			}
			waitGroup.Done()
		}(i)
	}

	waitGroup.Wait()

	fmt.Println(fmt.Sprint(len(etfs)) + " / " + fmt.Sprint(len(etfs)))

	for i := 0; i < len(etfs); i++ {
		for j := 0; j < len(etfs[i].Equity); j++ {
			etfs[i].EquityValue += etfs[i].Equity[j].MarketValue
		}

		etfs[i].TotalValue = etfs[i].EquityValue + etfs[i].NonEquityValue

		etfs[i].FairPrice = etfs[i].TotalValue / float64(etfs[i].SharesOutstanding)

		etfs[i].Premium = etfs[i].MarketPrice / etfs[i].FairPrice - 1
	}
	return nil
}

func save_etfs(etfs []ETF) error {
	for i := 0; i < len(etfs); i++ {
		file, err := os.Create("../data_etfs/" + etfs[i].ProductID + ".bin")
		if err != nil {
			return err
		}

		encoder := gob.NewEncoder(file)

		err = encoder.Encode(etfs[i])
		if err != nil {
			return err
		}

		file.Close()
	}

	return nil
}

func Load_etfs() ([]ETF, error) {
	files, err := ioutil.ReadDir("../data_etfs")
	if err != nil {
		return nil, err
	}

	etfs := make([]ETF, len(files))
	for i, file := range files {
		file, err := os.Open("../data_etfs/" + file.Name())
		if err != nil {
			return nil, err
		}

		decoder := gob.NewDecoder(file)

		var etf ETF
		err = decoder.Decode(&etf)
		if err != nil {
			return nil, err
		}

		etfs[i] = etf

		file.Close()
	}

	return etfs, nil
}

func Download(link string) ([]byte, error) {
	resp, err := http.Get(link)
	if err != nil {
		return nil, err
	}

	body, err := ioutil.ReadAll(resp.Body)
	if err != nil {
		return nil, err
	}

	return body, nil
}
